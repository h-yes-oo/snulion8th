from django.contrib import admin

from django.contrib import admin
from .models import Feed   # 추가

admin.site.register(Feed)   # 추가
# Register your models here.